local-results.csv仅为本工具计算，不能作为独立参考。
在指定商用软件复现project.json的参数、端口、噪声温度、求解器和非线性模型后，填写reference-template.csv。
基础标量链路提供run_reference.m时可在MATLAB RF Toolbox运行；脚本尚未在本机商业环境执行。
高级模型需在目标软件重建同一数据模型，不能用Friis结果验收谐波平衡。
导入时填写case.json中的calculation_hash与外部软件版本、求解器、来源。对比通过仅适用于该输入与指标。
