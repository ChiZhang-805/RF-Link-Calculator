% RF Link scalar Friis reference. Requires MATLAB RF Toolbox.
% This file is generated, not executed or certified by RF Link.
clear elements;
rows = cell(0,5);
e1 = amplifier('Name','stage1','Gain',-2,'NF',2.0000000000000004,'OIP3',Inf);
e2 = amplifier('Name','stage2','Gain',20,'NF',1.5000000000000002,'OIP3',25);
e3 = amplifier('Name','stage3','Gain',10,'NF',5.0,'OIP3',20);
elements = [e1 e2 e3];
b = rfbudget(elements,100000000.0,-60.0,1000000.0);
b.Solver = 'Friis';
computeBudget(b);
keys = {'gain_db','nf_db','iip3_dbm','linear_output_dbm','frequency_output_hz'};
units = {'dB','dB','dBm','dBm','Hz'};
values = [b.TransducerGain(:),b.NF(:),b.IIP3(:),b.OutputPower(:),b.OutputFrequency(:)];
ids = {native2unicode(uint8([50 100 102 49 57 99 97 97 45 54 101 100 99 45 53 56 51 100 45 98 49 50 54 45 102 54 102 52 98 54 54 99 101 57 57 98]), 'UTF-8'),native2unicode(uint8([101 57 102 97 97 99 52 48 45 49 97 57 49 45 53 97 98 48 45 56 53 51 99 45 48 99 49 100 99 100 52 99 51 49 99 50]), 'UTF-8'),native2unicode(uint8([53 55 101 101 56 50 102 56 45 56 55 98 51 45 53 55 98 53 45 57 56 97 57 45 98 101 51 49 53 53 98 48 50 54 50 51]), 'UTF-8')};
for i = 1:size(values,1)
  for k = 1:5
    status = 'valid'; v = sprintf('%.15g',values(i,k));
    if isinf(values(i,k)), status = 'ideal'; v = ''; end
    rows(end+1,:) = {ids{i},keys{k},v,units{k},status};
  end
end
for k = 1:5
  r = rows(15-5+k,:); r{1} = 'chain'; rows(end+1,:) = r;
end
T = cell2table(rows,'VariableNames',{'scope','metric','value','unit','status'});
writetable(T,'reference.csv');
meta.software = 'MATLAB RF Toolbox';
meta.version = version; meta.solver = 'Friis'; meta.source = 'commercial';
meta.calculation_hash = 'b9cbe22029ebd61f35a72abdf1d16d74ffb45bd264ed1d150e4c6d022c96de2e';
fid = fopen('reference-metadata.json','w'); fprintf(fid,'%s',jsonencode(meta)); fclose(fid);
